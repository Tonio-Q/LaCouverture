﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

namespace LaCouverture
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
                conn.Open();
                string checkuser = "select count(*) from tblUserData where Email = '" + txtEmail.Text + "'";
                SqlCommand com = new SqlCommand(checkuser, conn);
                int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
                conn.Close();
                if (temp == 1)
                {
                    Response.Write("User already exists");
                }

            }

        }

        protected void btnRegister_Click1(object sender, EventArgs e)
        {
            try
            {
                Guid newGUID = Guid.NewGuid();


                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
                conn.Open();
                string insertQuery = "insert into tblUserData(ID, FirstName, LastName, Email, Password, user_id) values (@ID, @fName, @lName, @email, @password, @user_id)";
                SqlCommand com = new SqlCommand(insertQuery, conn);
                com.Parameters.AddWithValue("@ID", newGUID.ToString());
                com.Parameters.AddWithValue("@fName", txtFName.Text);
                com.Parameters.AddWithValue("@lName", txtLName.Text);
                com.Parameters.AddWithValue("@email", txtEmail.Text);
                com.Parameters.AddWithValue("@password", txtPassword.Text);
                com.Parameters.AddWithValue("@user_id", 1);
                com.ExecuteNonQuery();
                //Response.Redirect("Manager.aspx");
                Response.Redirect("Login.aspx");
                Response.Write("Registration is successful");

                conn.Close();
            }
            catch (Exception ex)
            {
                Response.Write("Error: " + ex.ToString());
            }


            //Response.Redirect("Login.aspx");

        }
    }
}