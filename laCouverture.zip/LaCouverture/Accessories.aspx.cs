﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary2;

namespace LaCouverture
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        ClassOne co = new ClassOne();
        protected void Page_Load(object sender, EventArgs e)
        {
            co.Category_id = 3;

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Button addToCart = (Button)sender;
            GridViewRow row = (GridViewRow)addToCart.NamingContainer;
            string firstCellText = row.Cells[0].Text; // here we are

            co.Item_id = Convert.ToInt32(firstCellText);
            co.Item_name = co._uspSearchItem().Tables["_uspSearchItem"].Rows[0][0].ToString();
            co.Item_price = Convert.ToDouble(co._uspSearchItem().Tables["_uspSearchItem"].Rows[0][1].ToString());
            co.Transaction_id = Convert.ToInt32(co._uspMaxTransaction_id().Tables
                ["_uspMaxTransaction_ID"].Rows[0][0]);
            co.Item_img = co._uspSearchItem().Tables["_uspSearchItem"].Rows[0][3].ToString();
            co._uspSubTransaction();
            Label1.Text = co.Item_name;

            // co.


        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {


        }
    }
}