﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary2;

namespace LaCouverture
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        ClassOne co = new ClassOne();
        int itemID=0, itemBought=0, subTransactionID=0;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["id"] != null)
            {
                int id = Convert.ToInt32(Request.QueryString["id"]);

                co.Subtransaction_id = id;
                Label1.Text = co._uspUserQuantity().Tables["_uspUserQuantity"].Rows[0][2].ToString();
                //tbQuantity.Text = co._uspUserQuantity().Tables["_uspUserQuantity"].Rows[0][4].ToString();
                co.Item_id = Convert.ToInt32(co._uspUserQuantity().Tables["_uspUserQuantity"].Rows[0][1]);

                
                itemID = co.Item_id;
                itemBought = co.Item_bought;
                subTransactionID = co.Subtransaction_id;
            }
           
           
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            co.Subtransaction_id = subTransactionID;
            co.Item_bought = Convert.ToInt32(tbQuantity.Text);
            co.Item_id = itemID;

                if(Convert.ToInt32(co.Item_bought)>=Convert.ToInt32(
                    tbQuantity.Text = co._uspGetItem().Tables["_uspGetItem"].Rows[0][3].ToString()))
                {
                    Label2.Text = "Warning: Not enough Stocks!";
                }
                else
                {
                    
                    co._uspUpdateCheckOut();
                    co._uspMinusQty();
                    Response.Redirect("checkout.aspx");
                    
                }

        }
    }
}