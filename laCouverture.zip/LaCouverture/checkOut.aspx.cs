﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary2;

namespace LaCouverture
{
    public partial class WebForm5 : System.Web.UI.Page
    {

        ClassOne co = new ClassOne();
        protected void Page_Load(object sender, EventArgs e)
        {
           
            co.Transaction_id = Convert.ToInt32(co._uspMaxTransaction_id().Tables
                ["_uspMaxTransaction_ID"].Rows[0][0]);
            co._uspDeleteCheckOutItem();
            GridView1.DataSource = co._uspCheckOut().Tables["_uspCheckOut"];
            GridView1.DataBind();
            
        }

        protected void GridView1_PageIndexChanging1(object sender, GridViewPageEventArgs e)
        {
            co.Transaction_id = Convert.ToInt32(co._uspMaxTransaction_id().Tables
                ["_uspMaxTransaction_ID"].Rows[0][0]);
            GridView1.PageIndex = e.NewPageIndex;
            GridView1.DataSource = co._uspCheckOut().Tables["_uspCheckOut"];
            GridView1.DataBind();
        }

        protected void GridView1_PageIndexChanged(object sender, EventArgs e)
        {

        }



        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var id = this.GridView1.DataKeys[e.RowIndex].Value;

           
            
            co.Subtransaction_id = Convert.ToInt32(id);
            co.Item_id = Convert.ToInt32(co._uspGetCheckOut().Tables
                ["_uspGetCheckOut"].Rows[0][2]);
            co.Item_qty = Convert.ToInt32(co._uspGetItem().Tables
                ["_uspGetItem"].Rows[0][3]);
            //quantity to back
            if (string.IsNullOrEmpty(co._uspGetCheckOut().Tables["_uspGetCheckOut"].Rows[0][5].ToString()))
            {
                co.Back_itemQty = 0;
            }
            else
            {
                co.Back_itemQty = Convert.ToInt32(co._uspGetCheckOut().Tables
                   ["_uspGetCheckOut"].Rows[0][5]);
            }

            co.Back_itemQty = co.Item_qty + co.Back_itemQty; 
            co._uspBackStock();
            co._uspDeleteCOItem();
            
            co.Transaction_id = Convert.ToInt32(co._uspMaxTransaction_id().Tables
                ["_uspMaxTransaction_ID"].Rows[0][0]);
            GridView1.DataSource = co._uspCheckOut().Tables["_uspCheckOut"];
            GridView1.DataBind();
            //Response.Redirect("ItemStock.aspx");
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            var id = this.GridView1.DataKeys[e.NewEditIndex].Value;
            Response.Redirect("quantity.aspx?id=" + id.ToString());
        }
        protected void addItemButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("addItem.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            GridView2.DataSource = co._uspTransactionTotal().Tables["_uspTransactionTotal"];
            GridView2.DataBind();

            
            

        }

        protected void GridView2_RowEditing(object sender, GridViewEditEventArgs e)
        {
            
            co.Total_bought = Convert.ToDecimal(GridView2.Rows[e.NewEditIndex].Cells[1].Text);
            co.Transaction_id = Convert.ToInt32(co._uspMaxTransaction_id().Tables
                ["_uspMaxTransaction_ID"].Rows[0][0]);
            co._uspUpdateTransaction();
            Response.Redirect("login.aspx");

        }

        

       

        

    }
}