﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary2;

namespace LaCouverture.Admin_Page
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        ClassOne co = new ClassOne();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            Guid newGUID = Guid.NewGuid();

            co.Account_id = newGUID.ToString();
            co.User_id = 2;
            co.Email = tbEmail.Text;
            co.Password = tbPassword.Text;
            co.Fname = tbFirstName.Text;
            co.Lname = tbLastName.Text;
            co._uspInsertAdmin();
            Response.Redirect("accountManagement.aspx");

            
        }
    }
}