﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary2;

namespace LaCouverture.Admin_Page
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        ClassOne co = new ClassOne();
        protected void Page_Load(object sender, EventArgs e)
        {



            GridView1.DataSource = co._uspGetAccounts().Tables["_uspGetAccounts"];
            GridView1.DataBind();
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var id = this.GridView1.DataKeys[e.RowIndex].Value;
            co.Account_id = Convert.ToString(id);
            co._uspDeleteAccount();
            Response.Redirect("accountManagement.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("addAdmin.aspx");
        }
    }
}