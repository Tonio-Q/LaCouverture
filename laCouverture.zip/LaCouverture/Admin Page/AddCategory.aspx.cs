﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary2;

namespace LaCouverture.Admin_Page
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        ClassOne co = new ClassOne();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            co.Category_id = 1;
            co.Category_name = tbCategoryName.Text;
            co._uspAddCategory();
            Response.Redirect("itemStock.aspx");

            
        }
    }
}