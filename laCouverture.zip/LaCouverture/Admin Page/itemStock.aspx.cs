﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary2;

namespace LaCouverture.Admin_Page
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        ClassOne co = new ClassOne();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                DropDownList1.DataSource = co._uspGetCategory().Tables["_uspGetCategory"];
                DropDownList1.DataTextField = "Category_name";
                DropDownList1.DataValueField = "Category_id";
                DropDownList1.DataBind();

                co.Category_id = 1;
                GridView1.DataSource = co._uspGetItemList().Tables["_uspGetItemList"];
                GridView1.DataBind();
            }

            
        }

       



        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            co.Category_id= Convert.ToInt32(DropDownList1.SelectedItem.Value);
            GridView1.DataSource = co._uspGetItemList().Tables["_uspGetItemList"];
            GridView1.DataBind();
        }

        protected void GridView1_PageIndexChanging1(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            co.Category_id = Convert.ToInt32(DropDownList1.SelectedItem.Value);
            GridView1.DataSource = co._uspGetItemList().Tables["_uspGetItemList"];
            GridView1.DataBind();
        }

        protected void GridView1_PageIndexChanged(object sender, EventArgs e)
        {

        }

        

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var id = this.GridView1.DataKeys[e.RowIndex].Value;
            co.Item_id = Convert.ToInt32(id);
            co._uspDeleteItem();
            GridView1.DataSource = co._uspGetItemList().Tables["_uspGetItemList"];
            GridView1.DataBind();
            Response.Redirect("ItemStock.aspx");
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            var id = this.GridView1.DataKeys[e.NewEditIndex].Value;
            Response.Redirect("itemEdit.aspx?id=" + id.ToString());
        }
        protected void addItemButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("addItem.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("addCategory.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("deleteCategory.aspx");
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    }
}