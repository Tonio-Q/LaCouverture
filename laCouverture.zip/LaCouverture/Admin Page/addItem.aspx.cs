﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary2;
using System.IO;

namespace LaCouverture.Admin_Page
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        ClassOne co = new ClassOne();
             
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DropDownList1.DataSource = co._uspGetCategory().Tables["_uspGetCategory"];
                DropDownList1.DataTextField = "Category_name";
                DropDownList1.DataValueField = "Category_id";
                DropDownList1.DataBind();
            }
        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            string FileName = Path.GetFileName(FileUpload1.PostedFile.FileName);


            FileUpload1.SaveAs(Server.MapPath("images/" + FileName));
             //Save files to disk

            co.Item_img = "Admin Page/images/" + FileName;
            co.Item_id = 1;
            co.Item_name = tbItemName.Text;
            co.Item_price = Convert.ToInt32(tbItemPrice.Text);
            co.Category_id = Convert.ToInt32(DropDownList1.SelectedItem.Value);
            co.Item_qty = Convert.ToInt32(tbItemQty.Text);
            co._uspAddItem();
            Response.Redirect("itemStock.aspx");


        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

            co.Category_id = Convert.ToInt32(DropDownList1.SelectedItem.Value);
       
        }
    }
}