﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary2;

namespace LaCouverture.Admin_Page
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        ClassOne co = new ClassOne();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DropDownList1.DataSource = co._uspGetCategory().Tables["_uspGetCategory"];
                DropDownList1.DataTextField = "Category_name";
                DropDownList1.DataValueField = "Category_id";
                DropDownList1.DataBind();
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            co.Category_id = Convert.ToInt32(DropDownList1.SelectedItem.Value);
            co._uspDeleteCategory();
            Response.Redirect("itemstock.aspx");
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

            co.Category_id = Convert.ToInt32(DropDownList1.SelectedItem.Value);

        }
    }
}