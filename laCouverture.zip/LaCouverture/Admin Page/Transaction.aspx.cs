﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary2;

namespace LaCouverture.Admin_Page
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        ClassOne co = new ClassOne();
        protected void Page_Load(object sender, EventArgs e)
        {
            co._uspDeleteNullTransact();
            if (!Page.IsPostBack)
            {
                co._uspDeleteNullTransact();
                co.Category_id = 1;
                GridView1.DataSource = co._uspGetTransaction().Tables["_uspGetTransaction"];
                GridView1.DataBind();
            }
        }

        protected void GridView1_PageIndexChanging1(object sender, GridViewPageEventArgs e)
        {
            co._uspDeleteNullTransact();
            GridView1.PageIndex = e.NewPageIndex;
            GridView1.DataSource = co._uspGetTransaction().Tables["_uspGetTransaction"];
            GridView1.DataBind();
        }
    }
}