﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using ClassLibrary2;

namespace LaCouverture
{
    public partial class WebForm3 : System.Web.UI.Page
    {
       ClassOne co = new ClassOne();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
                conn.Open();
                string checkuser = "select count(*) from tblUserData where Email = '" + txtEmail.Text + "'";
                SqlCommand com = new SqlCommand(checkuser, conn);
                int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
                conn.Close();
                string email = txtEmail.Text.ToString();
                string pass = txtPassword.Text.ToString();
                co.Email = email;

                if (2 == Convert.ToInt32(co._uspGetUserIDandAccountID().Tables
                    ["_uspGetUserIDandAccountID"].Rows[0][0]) &&
                    pass.Equals(Convert.ToString(co._uspGetUserIDandAccountID().Tables
                    ["_uspGetUserIDandAccountID"].Rows[0][1])))
                {
                    Response.Redirect("~/Admin Page/ItemStock.aspx");
                }

                if (temp == 1)
                {
                    conn.Open();
                    string checkPasswordQuery = "select password from tblUserData where Email = '" + txtEmail.Text + "'";
                    SqlCommand passComm = new SqlCommand(checkPasswordQuery, conn);
                    string password = passComm.ExecuteScalar().ToString().Replace(" ", "");
                    if (password == txtPassword.Text)
                    {
                        Session["New"] = txtEmail.Text;
                        Response.Write("Password is correct.");
                        co.Email = txtEmail.Text;
                        co.Account_id = co._uspGetAccount_ID().Tables["_uspGetAccount_ID"].Rows[0][0].ToString();
                        co._uspInsertTransaction();
                        Response.Redirect("Home.aspx");
                    }
                    else
                    {
                        lblError.Text = ("Password is not correct").ToString();
                        //Response.Write("Password is not correct");
                    }
                }
                else
                {
                    lblError.Text = ("Email is not correct").ToString(); ;
                    //Response.Write("Email is not correct");
                }
            }
            catch(Exception h)
            {
                lblError.Text = "Invalid Email/Password";
            }
        }
    }
}