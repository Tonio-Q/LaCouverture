﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary2;

namespace LaCouverture
{
    public partial class MASTER : System.Web.UI.MasterPage
    {
        ClassOne co = new ClassOne();
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
       
        protected void checkOut_Click(object sender, EventArgs e)
        {
            co._uspDeleteCheckOutItem();

            Response.Redirect("checkout.aspx");

        }
       
    }
}