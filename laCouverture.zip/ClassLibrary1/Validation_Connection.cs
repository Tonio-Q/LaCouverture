﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
    public class Validation_Connection
    {
        public static string ConString()
        {
            return @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\QUEBEC\Desktop\ASP\LaCouverture\LaCouverture\App_Data\Database1.mdf;Integrated Security=True;User Instance=True";
        }
    }
}
